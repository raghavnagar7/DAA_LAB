#include<stdio.h>
#include<string.h>
int main()

{
   printf("%d\n%d\n%d",sizeof('h'),sizeof("h"),sizeof("h"));
    return 0;
}